# CAPTAIN's LOG :: Around React - Around The U.S.

**Description**

Sprint 10 & 11 is my first projects on React. I recoded all of the contents upto Project 9 in JSX and made it simplified in several components in React Way.


**Techniques & Tech**
In Project 10 I used React Tools and Hooks basically. In Project 11 I started to use React Tools more advanced also React Hooks became a common part of the components. useState, useEffect hooks used to set status and make function calls based on the "set" status.
Also api's used more efficiently and App.js became a proper port for them.
React & Data usage exercised with multiple functions and their corresponding api's.

*functions and api calls for data
*useState
*useEffect
*Lifting up state & global state
*Creating and using context



**GitHub**
https://namerm.github.io/around-react

